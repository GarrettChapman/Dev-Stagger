insert into bars_table
