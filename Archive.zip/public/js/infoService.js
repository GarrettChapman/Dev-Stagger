angular.module('myApp').service('infoService', function($http){


  })
