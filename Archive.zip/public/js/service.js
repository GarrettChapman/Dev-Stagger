angular.module('myApp').service('service', function($http) {
  this.barData = [];

})
