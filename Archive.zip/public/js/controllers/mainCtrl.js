angular.module('myApp').controller('mainCtrl', function($scope){
  $scope.test = 'Most Triumphant'
  // $scope.goToSite = function(){
  //
  // }

});
