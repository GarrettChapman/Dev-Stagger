angular.module('myApp').controller('infoCtrl', function($scope){
  $scope.test = "working>?";

//   $scope.getRandomBar = function() {
//     var random = Math.floor(Math.random() * bars.length)
//     var randomBar = bars.slice(random, random + 1)
//     map(randomBar)
// }
})
