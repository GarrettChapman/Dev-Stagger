module.exports = {
  yelpToken: "Bearer ez5o1DZioh8NDdcsMUdjvGE1-PzgWWKDm0F_bI5VWQm-jY6aXaZMLhlCa6Js3gKu5RyFsJpQ4g1z1F-wzIpSxvC7lW7KIHepntSJrwThPD04MCjudneqoNI_fXZaWXYx",

  postgres: 'postgress://zerocool@localhost/bars',
  session: {
    secret: 'mosttriumphant',
    resave: false,
    saveUninitialized: false
  }



}
